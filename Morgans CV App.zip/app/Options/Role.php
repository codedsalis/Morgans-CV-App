<?php

namespace App\Options;

class Role
{
    const USER = 'user';
    const ADMIN = 'admin';
}
